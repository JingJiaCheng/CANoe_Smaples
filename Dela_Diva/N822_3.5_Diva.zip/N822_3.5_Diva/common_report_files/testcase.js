function showTimestamp(timestamp)
{
  top.LogFile.showTimestamp(timestamp);
}        
  
function IsInDiVa(version)
{
   try{
	 if ((top==null) || (top.LogFile==null)) return false;
	 return top.LogFile.IsInDiVa(version);
   } catch(e) 
   {
	 return false;
   }
 }
 
	
function DeleteComment(reference)
{
	if (!IsInDiVa('2.2')) return;    
	if ((top==null) || (top.LogFile==null)) return ; 
	return top.LogFile.DeleteComment(reference);
}
 function UnlinkRequirement(link, title)
{
	if (!IsInDiVa('2.5')) return;    
	if ((top==null) || (top.LogFile==null)) return ; 
	return top.LogFile.UnlinkRequirement(link,title);
}
		
 function EditComment(reference)
{
	if (!IsInDiVa('2.2')) return;   
	if ((top==null) || (top.LogFile==null)) return ; 
	return top.LogFile.EditComment(reference);
}         
	
 function AdjustCommentTableForIsInDiVa()
{          
  if (!IsInDiVa('2.2')) return;                    
	 var tbl = document.getElementById('CommentsTable');	             
   if  (tbl==null) return
   var len = tbl.rows.length;
   for(i=0 ; i < len; i++)
   {	  
	tbl.rows[i].cells[5].style.display  = '';           
		 }
}  

function AdjustRequirementTableForIsInDiVa()
{          
  if (!IsInDiVa('2.5')) return;                    
  var tbl = document.getElementById('Req');	             
  if  (tbl==null) return
  var len = tbl.rows.length;
  for(i=0 ; i < len; i++)
  {	  
	tbl.rows[i].cells[1].style.display  = '';           
  }
  var gentbl = document.getElementById('GenReq');	             
  if  (gentbl==null) return
  var genlen = gentbl.rows.length;
  for(i=0 ; i < genlen; i++)
  {	  
	gentbl.rows[i].cells[1].style.display  = '';           
  }
}  
	
 function CorrectCddLinks(){		
 try{            
	var cdd=top.LogFile.GetCdd();         
	var links=document.getElementsByName("DiagDescLink");		   			            
	if  (links==null) return
	for(i=0 ; i < links.length; i++){				   
	  var origlinkText=links[i].href;										   
	  var service=origlinkText.substring(origlinkText.indexOf("#"));           
	  var protocol=origlinkText.substring(0,origlinkText.indexOf(":"));                         
	  var linkText=protocol+'://'+cdd+service;				   
	  links[i].setAttribute("href",linkText);				   				
	}
 }catch(e){}
   }


   function showHideRow(tabid, id,anchor) {		  	   
		var firstId='first_'+id;
		tbl = document.getElementById(tabid);	  
		if  (tbl==null) return
		var len = tbl.rows.length;	
	
		for(i=0 ; i < len; i++){	
	
				if ((tbl.rows[i].getAttribute('id')==id)){
					if  (tbl.rows[i].style.display=='none'){	
						tbl.rows[i].style.display  = ''; 	
					} else {		
						tbl.rows[i].style.display  = 'none'   ;
					}
				}
			
		}
	GoToAnchor(anchor);
  }

  function hideAll( tabid){
	tbl = document.getElementById(tabid);	  
	if  (tbl==null) return
	var len = tbl.rows.length;
	if (len < 1) return;
	for(i=0 ; i < len; i++){		
		var id=tbl.rows[i].getAttribute('id');		
		if ((id!=null) && (id.indexOf('first_')!=0) && (id!=''))
		{			
			tbl.rows[i].style.display  = 'none';					
		}		
		
	}

	var tbl = document.getElementById(tabid);	  
	var imgs=tbl.getElementsByTagName('img');			
	for (j=0;j < imgs.length;j++){																	  
			  imgs[j].setAttribute('src', '../common_report_files/btnPlus.gif');
	}	
	ReGoToAnchor();
  }
  
  function ReGoToAnchor()
  {
	//var page= window.location.href ;
	var anchor=window.location.hash.substring(1);	
	GoToAnchor(anchor);
  }		
  

 function GoToAnchor(anchor)
 {	  	
	 if (anchor==null) return;
	 var currentAnchor=window.location.hash.substring(1);			
	 if ((!isIE()) && (currentAnchor==anchor)){		 
		tbl = document.getElementsByName(anchor)[0];				 				
		if (tbl==null) return;				
		tbl.scrollIntoView();					
	  } else {
		window.location.hash=anchor;
	  }
  }
  


  function isIE()   
  {   
		return /msie/i.test(navigator.userAgent) && !/opera/i.test(navigator.userAgent);
  }		

   function showAll( tabid){
		tbl = document.getElementById(tabid);	  
		if  (tbl==null) return
		var len = tbl.rows.length;		
		for(i=0 ; i < len; i++){		
			var id=tbl.rows[i].getAttribute('id');		
			if ((id!=null) && (id.indexOf('first_')!=0)){			
				tbl.rows[i].style.display  = '';				
			}		
		}
	  var tbl = document.getElementById(tabid);	  
	  var imgs=tbl.getElementsByTagName('img');			
		for (j=0;j < imgs.length;j++){																	 
		   imgs[j].setAttribute('src', '../common_report_files/btnMinus.gif');
		}
		ReGoToAnchor();
  }		  		
  
  function initialReqMarker() {
	var css = document.styleSheets[0];
	var theRules = new Array();
	if (css.cssRules) {
		theRules = css.cssRules; // for FF et al
	} else if (css.rules) {
		theRules = css.rules;	// for IE 8
	}
	var rule = ".tcall a";
	if (css.insertRule){
		css.insertRule(rule + " { font-weight:normal; color:#06c; }", theRules.length); // for FF et al
	} else if (css.addRule){
		css.addRule(rule, "font-weight:normal; color:#06c;");	// for IE 8
	}
}		  		  


function markReqsForTestCommand(testCommandID) {
	markReqsForTestCommandWithStyle(testCommandID, " color:#06c; ");
}

function markReqsForTestCommandWithStyle(testCommandID, style) {
	var css = document.styleSheets[0];
	var theRules = new Array();
	if (css.cssRules) {
		theRules = css.cssRules; // for FF et al
	} else if (css.rules) {
		theRules = css.rules;	// for IE 8
	}
	if (css.deleteRule){
		css.deleteRule(theRules.length - 1); // for FF et al
	} else if (css.removeRule) {
		css.removeRule(theRules.length - 1);	// for IE 8
	}
	var rule = ".tc"+testCommandID + " a";
	if (css.insertRule){
		css.insertRule(rule + " { "+ style + " }", theRules.length); // for FF et al
	} else if (css.addRule){
		css.addRule(rule, style);	// for IE 8
	}
	GoToAnchor("RequirementsHeading");
}

function changeRequirementText(text) {
	if (document.getElementById('MarkedReqText'))
		document.getElementById('MarkedReqText').firstChild.nodeValue = text;
}

function showReqsAndMarkedInfo(){
	 showRequirements(); 
	 if (document.getElementById('MarkedReqSpanInner'))
		 document.getElementById('MarkedReqSpanInner').style.display = '';
}

function showRequirements(){
	showAll('Req'); 
	showAll('GenReq');
	if (document.getElementById('MarkedReqSpan'))
		document.getElementById('MarkedReqSpan').style.display  = '';
}

function hideRequirements(){
	hideAll('Req');
	hideAll('GenReq');
	if (document.getElementById('MarkedReqSpan'))
		document.getElementById('MarkedReqSpan').style.display  = 'none';
}	 